import { createNativeStackNavigator } from "@react-navigation/native-stack";
import PVItem from "../screens/PVItem";
import ItemPreview from "../screens/ItemPreview";
import Barcode from "../screens/Barcode";
import ItemsCollected from "../screens/ItemsCollected";

type StackParamList = {
  PVItem: { payload?: { pv: string; loadProducts?: boolean } };
  ItemPreview: undefined;
  ItemsCollected: undefined;
  Login: undefined;
  BarCode: undefined;
};

const Stack = createNativeStackNavigator<StackParamList>();

export default function StackRoutes() {
  return (
    <Stack.Navigator
      initialRouteName="PVItem"
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="PVItem" component={PVItem} />
      <Stack.Screen name="ItemPreview" component={ItemPreview} />
      <Stack.Screen name="ItemsCollected" component={ItemsCollected} />
      <Stack.Screen name="Login" component={PVItem} />
      <Stack.Screen name="BarCode" component={Barcode} />
    </Stack.Navigator>
  );
}
