import styled from "styled-components/native";

export const ButtonContainer = styled.View`
    flex: 1;
`;

export const TipContainer = styled.View`
    flex: 1;
    justify-content: flex-end;
`;
