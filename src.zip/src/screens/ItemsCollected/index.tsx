import { RouteProp, useNavigation } from "@react-navigation/native";
import BackButton from "../../components/BackButton";
import Header from "../../components/Header";
import InformationTable from "../../components/InformationTable";
import { ContainerView } from "../../global/styles/theme";
import { ApiReadItem, RootStackParamList } from "../../routes";
import {
  NativeStackScreenProps,
} from '@react-navigation/native-stack';

type Props = NativeStackScreenProps<RootStackParamList, 'ItemsCollected'>;

export default function ItemsCollected({ route, navigation }: Props) {
    const { inputPV, itemsPV } = route.params;

    function handleBack() {
        navigation.goBack();
    }

    return (
        <>
            <ContainerView>
                <Header title={`PV:${inputPV}`} description="Todos os itens lidos:" />
                <BackButton onPress={handleBack} />
            </ContainerView>
            <InformationTable data={itemsPV} />
        </>
    );
}
